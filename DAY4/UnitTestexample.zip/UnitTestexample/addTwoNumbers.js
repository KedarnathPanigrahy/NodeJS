function addTwoNumbers(x, y) {

  
    // if(x==2){
    //   console.log("s");
    // }else{
    //   console.log(x+y);

    // }
    
   if(true){
     console.log("xczxcx");
   }else{
     console.log("else");
   }


    return x + y;
  }
  module.exports = addTwoNumbers;